package com.teletop.masterplus;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.os.Build;
import android.os.IBinder;

import java.util.HashMap;
import java.util.Map;

public class BackgroundAudioService extends Service {

    public static final String ACTION_START = "com.teletop.masterplus.action.START_AUDIO";
    public static final String ACTION_TOGGLE = "com.teletop.masterplus.action.TOGGLE_AUDIO";
    public static final String ACTION_STOP = "com.teletop.masterplus.action.STOP_AUDIO";

    public static final String EXTRA_URL = "url";
    public static final String EXTRA_USER_AGENT = "user_agent";
    public static final String EXTRA_COOKIE = "cookie";
    public static final String EXTRA_REFERER = "referer";

    private static final String CHANNEL_ID = "masterplus_background_audio";
    private static final int NOTIFICATION_ID = 1010;

    private MediaPlayer mediaPlayer;
    private MediaSession mediaSession;
    private boolean prepared;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();

        mediaSession = new MediaSession(this, "MasterPlusBackgroundAudio");
        mediaSession.setCallback(new MediaSession.Callback() {
            @Override
            public void onPlay() {
                resumePlayback();
            }

            @Override
            public void onPause() {
                pausePlayback();
            }

            @Override
            public void onStop() {
                stopSelfSafely();
            }
        });
        mediaSession.setActive(true);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            return START_NOT_STICKY;
        }

        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopSelfSafely();
            return START_NOT_STICKY;
        }

        if (ACTION_TOGGLE.equals(action)) {
            if (mediaPlayer != null && prepared && mediaPlayer.isPlaying()) {
                pausePlayback();
            } else {
                resumePlayback();
            }
            return START_STICKY;
        }

        if (ACTION_START.equals(action)) {
            String url = intent.getStringExtra(EXTRA_URL);
            if (url == null || url.trim().isEmpty()) {
                stopSelfSafely();
                return START_NOT_STICKY;
            }
            startForeground(NOTIFICATION_ID, buildNotification(false));
            startMedia(url, intent);
            return START_STICKY;
        }

        return START_NOT_STICKY;
    }

    private void startMedia(String url, Intent intent) {
        releasePlayer();
        prepared = false;

        mediaPlayer = new MediaPlayer();
        mediaPlayer.setAudioAttributes(
                new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
        );
        mediaPlayer.setWakeMode(getApplicationContext(), android.os.PowerManager.PARTIAL_WAKE_LOCK);

        mediaPlayer.setOnPreparedListener(player -> {
            prepared = true;
            player.start();
            updateNotification(true);
            updatePlaybackState(true);
        });
        mediaPlayer.setOnCompletionListener(player -> stopSelfSafely());
        mediaPlayer.setOnErrorListener((player, what, extra) -> {
            stopSelfSafely();
            return true;
        });

        try {
            Map<String, String> headers = new HashMap<>();
            String userAgent = intent.getStringExtra(EXTRA_USER_AGENT);
            String cookie = intent.getStringExtra(EXTRA_COOKIE);
            String referer = intent.getStringExtra(EXTRA_REFERER);
            if (userAgent != null && !userAgent.isEmpty()) headers.put("User-Agent", userAgent);
            if (cookie != null && !cookie.isEmpty()) headers.put("Cookie", cookie);
            if (referer != null && !referer.isEmpty()) headers.put("Referer", referer);

            mediaPlayer.setDataSource(this, android.net.Uri.parse(url), headers);
            mediaPlayer.prepareAsync();
        } catch (Exception error) {
            stopSelfSafely();
        }
    }

    private void resumePlayback() {
        if (mediaPlayer != null && prepared) {
            try {
                mediaPlayer.start();
                updateNotification(true);
                updatePlaybackState(true);
            } catch (Exception ignored) {
            }
        }
    }

    private void pausePlayback() {
        if (mediaPlayer != null && prepared) {
            try {
                mediaPlayer.pause();
                updateNotification(false);
                updatePlaybackState(false);
            } catch (Exception ignored) {
            }
        }
    }

    private void updatePlaybackState(boolean playing) {
        if (mediaSession == null) return;
        long actions = android.media.session.PlaybackState.ACTION_PLAY
                | android.media.session.PlaybackState.ACTION_PAUSE
                | android.media.session.PlaybackState.ACTION_PLAY_PAUSE
                | android.media.session.PlaybackState.ACTION_STOP;
        android.media.session.PlaybackState state = new android.media.session.PlaybackState.Builder()
                .setActions(actions)
                .setState(
                        playing
                                ? android.media.session.PlaybackState.STATE_PLAYING
                                : android.media.session.PlaybackState.STATE_PAUSED,
                        android.media.session.PlaybackState.PLAYBACK_POSITION_UNKNOWN,
                        1.0f
                )
                .build();
        mediaSession.setPlaybackState(state);
    }

    private Notification buildNotification(boolean playing) {
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPendingIntent = PendingIntent.getActivity(
                this,
                1,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent toggleIntent = new Intent(this, BackgroundAudioService.class);
        toggleIntent.setAction(ACTION_TOGGLE);
        PendingIntent togglePendingIntent = PendingIntent.getService(
                this,
                2,
                toggleIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Intent stopIntent = new Intent(this, BackgroundAudioService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPendingIntent = PendingIntent.getService(
                this,
                3,
                stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Action toggleAction = new Notification.Action.Builder(
                android.R.drawable.ic_media_play,
                playing ? "Pausar" : "Reproducir",
                togglePendingIntent
        ).build();

        Notification.Action stopAction = new Notification.Action.Builder(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Detener",
                stopPendingIntent
        ).build();

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        builder.setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("MasterPlus")
                .setContentText("Reproduciendo audio en segundo plano")
                .setContentIntent(openPendingIntent)
                .setOngoing(playing)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setCategory(Notification.CATEGORY_TRANSPORT)
                .addAction(toggleAction)
                .addAction(stopAction)
                .setStyle(new Notification.MediaStyle()
                        .setMediaSession(mediaSession.getSessionToken())
                        .setShowActionsInCompactView(0, 1));

        return builder.build();
    }

    private void updateNotification(boolean playing) {
        NotificationManager manager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(NOTIFICATION_ID, buildNotification(playing));
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Audio en segundo plano",
                    NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Controles de reproducción de MasterPlus");
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private void stopSelfSafely() {
        releasePlayer();
        stopForeground(true);
        stopSelf();
    }

    private void releasePlayer() {
        prepared = false;
        if (mediaPlayer != null) {
            try { mediaPlayer.stop(); } catch (Exception ignored) {}
            try { mediaPlayer.reset(); } catch (Exception ignored) {}
            try { mediaPlayer.release(); } catch (Exception ignored) {}
            mediaPlayer = null;
        }
    }

    @Override
    public void onDestroy() {
        releasePlayer();
        if (mediaSession != null) {
            mediaSession.setActive(false);
            mediaSession.release();
            mediaSession = null;
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
