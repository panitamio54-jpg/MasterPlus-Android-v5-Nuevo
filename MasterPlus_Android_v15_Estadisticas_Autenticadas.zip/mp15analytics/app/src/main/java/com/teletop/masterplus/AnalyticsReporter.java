package com.teletop.masterplus;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.util.Log;
import android.webkit.CookieManager;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * MasterPlus v15:
 * envía estadísticas autenticadas usando la misma cookie del WebView
 * y cuerpo JSON compatible con request_json() de api/track.php.
 */
public final class AnalyticsReporter {
    private static final String TAG = "MasterPlusAnalytics";
    private static final String BASE_URL = "https://teletop.online/Masterplus/";
    private static final String ENDPOINT = BASE_URL + "api/track.php";

    private final Context context;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final String sessionId = UUID.randomUUID().toString();

    public AnalyticsReporter(Context context) {
        this.context = context.getApplicationContext();
    }

    public void send(String eventType, String pageUrl, String contentName,
                     String categoryName, String contentType, boolean playing) {
        executor.execute(() -> post(
                eventType, pageUrl, contentName, categoryName, contentType, playing
        ));
    }

    private void post(String eventType, String pageUrl, String contentName,
                      String categoryName, String contentType, boolean playing) {
        HttpURLConnection connection = null;
        try {
            JSONObject body = new JSONObject();
            body.put("event_type", safe(eventType));
            body.put("session_id", sessionId);
            body.put("page_url", safe(pageUrl));
            body.put("channel_name", safe(contentName));
            body.put("category_name", safe(categoryName));
            body.put("content_type", normalizeContentType(contentType));
            body.put("is_playing", playing);
            body.put("device_model", Build.MANUFACTURER + " " + Build.MODEL);
            body.put("device_type", "Android");
            body.put("os_version", Build.VERSION.RELEASE);
            body.put("app_version", BuildConfig.VERSION_NAME);
            body.put("connection_type", getConnectionType());
            body.put("browser_name", "MasterPlus Android");
            body.put("timestamp_ms", System.currentTimeMillis());

            CookieManager cookieManager = CookieManager.getInstance();
            cookieManager.flush();

            String cookie = cookieManager.getCookie(BASE_URL);
            if ((cookie == null || cookie.trim().isEmpty()) && pageUrl != null && !pageUrl.isEmpty()) {
                cookie = cookieManager.getCookie(pageUrl);
            }

            URL url = new URL(ENDPOINT);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(10000);
            connection.setReadTimeout(10000);
            connection.setDoOutput(true);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", "MasterPlusAndroid/" + BuildConfig.VERSION_NAME);
            connection.setRequestProperty("X-Requested-With", "com.teletop.masterplus");

            if (cookie != null && !cookie.trim().isEmpty()) {
                connection.setRequestProperty("Cookie", cookie);
            } else {
                Log.w(TAG, "No se encontró cookie de sesión para enviar " + eventType);
            }

            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(bytes.length);

            try (OutputStream output = connection.getOutputStream()) {
                output.write(bytes);
                output.flush();
            }

            int status = connection.getResponseCode();
            String response = readResponse(
                    status >= 200 && status < 400
                            ? connection.getInputStream()
                            : connection.getErrorStream()
            );

            if (status < 200 || status >= 300) {
                Log.w(TAG, "track.php respondió HTTP " + status + ": " + response);
            } else {
                Log.d(TAG, "Evento " + eventType + " registrado: " + response);
            }
        } catch (Exception e) {
            Log.w(TAG, "No se pudo enviar estadística: " + e.getMessage());
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    private static String readResponse(InputStream stream) {
        if (stream == null) return "";
        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
        } catch (Exception ignored) {
        }
        return result.toString();
    }

    private String getConnectionType() {
        try {
            ConnectivityManager cm = (ConnectivityManager)
                    context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return "Desconocida";

            Network network = cm.getActiveNetwork();
            if (network == null) return "Sin conexión";

            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            if (caps == null) return "Desconocida";

            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "Wi-Fi";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "Datos móviles";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "Ethernet";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return "VPN";
            return "Otra";
        } catch (Exception ignored) {
            return "Desconocida";
        }
    }

    private static String normalizeContentType(String value) {
        String normalized = safe(value).toLowerCase();
        if ("pelicula".equals(normalized) || "movie".equals(normalized)) return "movie";
        if ("app".equals(normalized)) return "app";
        if ("other".equals(normalized)) return "other";
        return "channel";
    }

    private static String safe(String value) {
        return value == null ? "" : value.trim();
    }

    public void shutdown() {
        executor.shutdownNow();
    }
}
