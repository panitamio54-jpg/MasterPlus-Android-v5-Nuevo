# MasterPlus Android v18 — Heartbeat en vivo

Cambios:
- heartbeat de estadísticas cada 20 segundos;
- primer envío 5 segundos después de abrir;
- reinicio seguro del heartbeat al volver a la app;
- mantiene token, device ID, reproducción estable, PiP y audio de fondo.

Resultado esperado:
- `last_seen_at` se mantiene reciente;
- el panel Revendedor > Actividad en vivo muestra al cliente en menos de 20 segundos.

Versión:
- versionCode 20
- versionName 2.6.0
