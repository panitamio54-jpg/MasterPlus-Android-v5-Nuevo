package com.teletop.masterplus;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.PictureInPictureParams;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Rational;
import android.os.Environment;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.PermissionRequest;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.graphics.Color;
import android.widget.VideoView;
import android.widget.MediaController;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Locale;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {

    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final int WEB_PERMISSION_REQUEST = 1002;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 1003;
    private static final String TRUSTED_HOST = "teletop.online";

    private FrameLayout rootContainer;
    private WebView webView;
    private ProgressBar progressBar;
    private VideoView nativeVideoView;

    private ValueCallback<Uri[]> filePathCallback;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;

    private PermissionRequest pendingPermissionRequest;
    private boolean videoIsFullscreen = false;
    private volatile boolean webVideoPlaying = false;
    private volatile String latestMediaUrl = "";
    private boolean nativePipActive = false;
    private String[] pendingAndroidPermissions;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private boolean pipTransitionPending = false;
    private int systemInsetTop = 0;
    private int systemInsetBottom = 0;
    private boolean backgroundAudioActive = false;
    private boolean screenReceiverRegistered = false;
    private boolean audioReceiverRegistered = false;
    private boolean pendingBackgroundAudio = false;

    // Estadísticas reales v14. No modifica el reproductor ni el audio de fondo.
    private AnalyticsReporter analyticsReporter;
    private volatile String analyticsContentName = "";
    private volatile String analyticsCategoryName = "";
    private volatile String analyticsContentType = "app";
    private volatile boolean analyticsStarted = false;
    private final Runnable analyticsHeartbeat = new Runnable() {
        @Override public void run() {
            captureAnalyticsContext();
            sendAnalyticsEvent("heartbeat");
            mainHandler.postDelayed(this, 30000);
        }
    };

    private final BroadcastReceiver screenStateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) {
                startBackgroundAudioIfPossible();
            } else if (Intent.ACTION_USER_PRESENT.equals(intent.getAction())) {
                stopBackgroundAudioAndRestore();
            }
        }
    };

    private final BroadcastReceiver audioStateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BackgroundAudioService.ACTION_PLAYBACK_READY.equals(action)) {
                pendingBackgroundAudio = false;
                backgroundAudioActive = true;
                pauseVisiblePlayer();
            } else if (BackgroundAudioService.ACTION_PLAYBACK_ERROR.equals(action)) {
                pendingBackgroundAudio = false;
                backgroundAudioActive = false;
                mainHandler.post(() -> Toast.makeText(MainActivity.this,
                        "No se pudo iniciar el audio en segundo plano para este canal",
                        Toast.LENGTH_LONG).show());
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_main);

        rootContainer = findViewById(R.id.rootContainer);
        webView = findViewById(R.id.webView);
        progressBar = findViewById(R.id.progressBar);
        nativeVideoView = findViewById(R.id.nativeVideoView);

        configureSystemBars();
        configureWebView();
        registerScreenStateReceiver();
        registerAudioStateReceiver();
        requestNotificationPermissionIfNeeded();
        updatePictureInPictureParams(false);

        analyticsReporter = new AnalyticsReporter(this);
        mainHandler.postDelayed(analyticsHeartbeat, 5000);

        if (savedInstanceState == null) {
            webView.loadUrl(BuildConfig.START_URL);
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();

        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccess(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        settings.setUserAgentString(
                settings.getUserAgentString() + " MasterPlusAndroid/1.0"
        );

        webView.addJavascriptInterface(new VideoStateBridge(), "MasterPlusBridge");

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new MasterPlusWebViewClient());
        webView.setWebChromeClient(new MasterPlusChromeClient());
        webView.setDownloadListener(createDownloadListener());

        webView.setLongClickable(true);
        webView.setHapticFeedbackEnabled(true);
    }

    private void updateKeepScreenOn(boolean keepOn) {
        if (keepOn) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    private void registerScreenStateReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_USER_PRESENT);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(screenStateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(screenStateReceiver, filter);
        }
        screenReceiverRegistered = true;
    }


    private void registerAudioStateReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(BackgroundAudioService.ACTION_PLAYBACK_READY);
        filter.addAction(BackgroundAudioService.ACTION_PLAYBACK_ERROR);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(audioStateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(audioStateReceiver, filter);
        }
        audioReceiverRegistered = true;
    }

    private boolean isBackgroundAudioEnabled() {
        return getSharedPreferences(BackgroundAudioService.PREFS, MODE_PRIVATE)
                .getBoolean("background_audio_enabled", true);
    }

    private void pauseVisiblePlayer() {
        webView.evaluateJavascript("window.MasterPlusNativePiP&&window.MasterPlusNativePiP.pause()", null);
        if (nativeVideoView != null && nativeVideoView.isPlaying()) nativeVideoView.pause();
        updateKeepScreenOn(false);
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    NOTIFICATION_PERMISSION_REQUEST
            );
        }
    }

    private void startBackgroundAudioIfPossible() {
        if (!isBackgroundAudioEnabled() || backgroundAudioActive || pendingBackgroundAudio
                || latestMediaUrl == null || latestMediaUrl.isEmpty()) return;
        if (!webVideoPlaying && !nativePipActive) return;

        try {
            Intent serviceIntent = new Intent(this, BackgroundAudioService.class);
            serviceIntent.setAction(BackgroundAudioService.ACTION_START);
            serviceIntent.putExtra(BackgroundAudioService.EXTRA_URL, latestMediaUrl);
            serviceIntent.putExtra(BackgroundAudioService.EXTRA_USER_AGENT,
                    webView.getSettings().getUserAgentString());
            String cookie = CookieManager.getInstance().getCookie(latestMediaUrl);
            serviceIntent.putExtra(BackgroundAudioService.EXTRA_COOKIE, cookie == null ? "" : cookie);
            serviceIntent.putExtra(BackgroundAudioService.EXTRA_REFERER,
                    webView.getUrl() == null ? BuildConfig.START_URL : webView.getUrl());
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent);
            else startService(serviceIntent);
            pendingBackgroundAudio = true;
        } catch (Exception e) {
            pendingBackgroundAudio = false;
            backgroundAudioActive = false;
        }
    }

    private void stopBackgroundAudioAndRestore() {
        if (!backgroundAudioActive) {
            return;
        }
        Intent stopIntent = new Intent(this, BackgroundAudioService.class);
        stopIntent.setAction(BackgroundAudioService.ACTION_STOP);
        startService(stopIntent);
        backgroundAudioActive = false;

        mainHandler.postDelayed(() -> {
            if (nativePipActive && nativeVideoView != null
                    && nativeVideoView.getVisibility() == View.VISIBLE) {
                try { nativeVideoView.start(); } catch (Exception ignored) {}
            } else if (webView != null) {
                webView.evaluateJavascript(
                        "window.MasterPlusNativePiP&&window.MasterPlusNativePiP.resume()",
                        null
                );
            }
            updateKeepScreenOn(webVideoPlaying);
        }, 250);
    }

    private DownloadListener createDownloadListener() {
        return (url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
                request.setMimeType(mimeType);
                request.addRequestHeader("User-Agent", userAgent);

                String cookie = CookieManager.getInstance().getCookie(url);
                if (cookie != null) {
                    request.addRequestHeader("Cookie", cookie);
                }

                String fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);
                request.setTitle(fileName);
                request.setDescription("MasterPlus");
                request.setNotificationVisibility(
                        DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
                );
                request.setDestinationInExternalPublicDir(
                        Environment.DIRECTORY_DOWNLOADS,
                        fileName
                );

                DownloadManager manager =
                        (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                manager.enqueue(request);

                Toast.makeText(
                        MainActivity.this,
                        R.string.download_started,
                        Toast.LENGTH_SHORT
                ).show();
            } catch (Exception error) {
                openExternal(Uri.parse(url));
            }
        };
    }


    private final class VideoStateBridge {
        @JavascriptInterface
        public void setMediaState(String url, boolean playing) {
            boolean changed = webVideoPlaying != playing;
            webVideoPlaying = playing;
            if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                latestMediaUrl = url;
            }
            mainHandler.post(() -> {
                updatePictureInPictureParams(playing && !latestMediaUrl.isEmpty());
                updateKeepScreenOn(playing);
                if (changed) sendAnalyticsEvent(playing ? "play" : "pause");
            });
        }

        @JavascriptInterface
        public void setContentContext(String name, String category, String type) {
            analyticsContentName = name == null ? "" : name;
            analyticsCategoryName = category == null ? "" : category;
            analyticsContentType = type == null || type.isEmpty() ? "canal" : type;
        }

        @JavascriptInterface
        public void openBufferSettings() {
            mainHandler.post(() -> showBufferSettingsDialog());
        }
    }

    private void captureAnalyticsContext() {
        if (webView == null) return;
        webView.evaluateJavascript(
                "(function(){try{" +
                "var clean=function(v){return (v||'').replace(/\\s+/g,' ').trim();};" +
                "var active=document.querySelector('[aria-selected=\\\"true\\\"],.active,.selected,.channel-active,.is-active');" +
                "var name='';var category='';" +
                "if(active){name=clean(active.getAttribute('data-name')||active.getAttribute('title')||active.textContent);}" +
                "if(!name){var h=document.querySelector('.channel-title,.player-title,.now-playing h1,.now-playing h2,[data-current-channel]');if(h)name=clean(h.textContent||h.getAttribute('data-current-channel'));}" +
                "if(!name)name=clean(document.title);" +
                "var c=document.querySelector('.category.active,.category.selected,[data-active-category]');if(c)category=clean(c.textContent||c.getAttribute('data-active-category'));" +
                "var type=(location.pathname.indexOf('movie')>=0||document.body.innerText.indexOf('Películas')>=0)?'pelicula':'canal';" +
                "if(window.MasterPlusBridge)window.MasterPlusBridge.setContentContext(name,category,type);" +
                "return name;}catch(e){return '';}})();", null);
    }

    private void sendAnalyticsEvent(String eventType) {
        if (analyticsReporter == null) return;
        String page = webView == null || webView.getUrl() == null
                ? BuildConfig.START_URL : webView.getUrl();
        analyticsReporter.send(eventType, page, analyticsContentName,
                analyticsCategoryName, analyticsContentType, webVideoPlaying || backgroundAudioActive);
    }

    private void showBufferSettingsDialog() {
        final int[] values = {40, 50, 60, 70, 80};
        final String[] labels = {"40 segundos", "50 segundos", "60 segundos", "70 segundos", "80 segundos"};
        android.content.SharedPreferences prefs = getSharedPreferences(BackgroundAudioService.PREFS, MODE_PRIVATE);
        int current = prefs.getInt(BackgroundAudioService.PREF_BUFFER_SECONDS, 50);
        int checked = 1;
        for (int i = 0; i < values.length; i++) if (values[i] == current) checked = i;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int)(20 * getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad / 2, pad, 0);

        TextView bufferTitle = new TextView(this);
        bufferTitle.setText("Búfer de reproducción");
        bufferTitle.setTextSize(17);
        bufferTitle.setTextColor(Color.rgb(35, 35, 35));
        box.addView(bufferTitle);

        RadioGroup group = new RadioGroup(this);
        for (int i = 0; i < labels.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setText(labels[i]); rb.setTextColor(Color.rgb(35, 35, 35)); rb.setTextSize(16); rb.setPadding(0, 8, 0, 8); rb.setId(1000 + i);
            group.addView(rb);
        }
        group.check(1000 + checked);
        box.addView(group);

        Switch audio = new Switch(this);
        audio.setText("Audio con pantalla apagada"); audio.setTextColor(Color.rgb(35, 35, 35)); audio.setTextSize(16); audio.setPadding(0, 16, 0, 8);
        audio.setChecked(prefs.getBoolean("background_audio_enabled", true));
        box.addView(audio);

        Switch reconnect = new Switch(this);
        reconnect.setText("Reconexión automática"); reconnect.setTextColor(Color.rgb(35, 35, 35)); reconnect.setTextSize(16); reconnect.setPadding(0, 8, 0, 8);
        reconnect.setChecked(prefs.getBoolean("auto_reconnect", true));
        box.addView(reconnect);

        new AlertDialog.Builder(this)
                .setTitle("Configuración")
                .setView(box)
                .setMessage("Un búfer mayor resiste mejor una conexión inestable, pero demora más en iniciar.")
                .setPositiveButton("Guardar", (dialog, which) -> {
                    int index = Math.max(0, group.getCheckedRadioButtonId() - 1000);
                    prefs.edit().putInt(BackgroundAudioService.PREF_BUFFER_SECONDS, values[index])
                            .putBoolean("background_audio_enabled", audio.isChecked())
                            .putBoolean("auto_reconnect", reconnect.isChecked()).apply();
                    Toast.makeText(this, "Configuración guardada", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", null).show();
    }

    private void installNativeSettingsEntry() {
        webView.evaluateJavascript(
                "(function(){try{"
                        + "function txt(e){return ((e&&e.textContent)||'').replace(/\\s+/g,' ').trim().toLowerCase();}"
                        + "function findExact(label){var els=document.querySelectorAll('div,li,button,a,span,p');for(var i=0;i<els.length;i++){var t=txt(els[i]);if(t===label||t.indexOf(label+' ')===0)return els[i];}return null;}"
                        + "var old=document.getElementById('masterplus-native-config');if(old&&document.body.contains(old))return 'exists';"
                        + "var a=findExact('contáctanos')||findExact('contactanos');if(!a)return 'waiting';"
                        + "var row=a;for(var n=0;n<5&&row.parentElement;n++){var r=row.getBoundingClientRect();var pr=row.parentElement.getBoundingClientRect();if(pr.width>r.width*1.15&&pr.height>=55&&pr.height<=150){row=row.parentElement;break;}row=row.parentElement;}"
                        + "var item=document.createElement('div');item.id='masterplus-native-config';item.setAttribute('role','button');item.style.cssText='display:flex!important;align-items:center!important;min-height:76px!important;padding:0 32px!important;border-top:1px solid rgba(255,255,255,.09)!important;border-bottom:1px solid rgba(255,255,255,.09)!important;font-size:18px!important;color:#fff!important;cursor:pointer!important;background:#151419!important;box-sizing:border-box!important;position:relative!important;z-index:20!important';"
                        + "item.innerHTML='<span style=\"font-size:25px;color:#ff5a16;width:54px\">⚙</span><span style=\"flex:1\">Configuración</span><span style=\"font-size:30px;color:#999\">›</span>';"
                        + "item.onclick=function(e){e.preventDefault();e.stopPropagation();if(window.MasterPlusBridge)window.MasterPlusBridge.openBufferSettings();};"
                        + "row.parentNode.insertBefore(item,row.nextSibling);return 'inserted';"
                        + "}catch(e){return 'error:'+e.message;}})();",
                null
        );
    }

    private void installVideoStateMonitor() {
        webView.evaluateJavascript(
                "(function(){"
                        + "if(window.__masterPlusNativePipInstalled)return;"
                        + "window.__masterPlusNativePipInstalled=true;"
                        + "function absolute(u){try{return new URL(u,document.baseURI).href;}catch(e){return '';}}"
                        + "function report(){"
                        + "var videos=[].slice.call(document.querySelectorAll('video'));"
                        + "var v=videos.find(function(x){return !x.paused&&!x.ended;})||videos[0];"
                        + "var src='';var playing=false;"
                        + "if(v){src=v.currentSrc||v.src||'';playing=!v.paused&&!v.ended;}"
                        + "if(!src){var source=document.querySelector('video source[src],source[src$=\".m3u8\"],source[src$=\".mp4\"]');if(source)src=source.src||source.getAttribute('src')||'';}"
                        + "if(window.MasterPlusBridge){MasterPlusBridge.setMediaState(absolute(src),playing);}"
                        + "}"
                        + "function cap(u){try{u=absolute(u);if(/\\.(m3u8|mp4)(\\?|$)|manifest\\.mpd/i.test(u)&&window.MasterPlusBridge)MasterPlusBridge.setMediaState(u,true);}catch(e){}}var of=window.fetch;if(of&&!of.__mp){window.fetch=function(){var a=arguments;cap(a[0]&&a[0].url?a[0].url:a[0]);return of.apply(this,a);};window.fetch.__mp=true;}var oo=XMLHttpRequest.prototype.open;if(!oo.__mp){XMLHttpRequest.prototype.open=function(m,u){cap(u);return oo.apply(this,arguments);};XMLHttpRequest.prototype.open.__mp=true;}function bind(){document.querySelectorAll('video').forEach(function(v){if(v.__mpNativeBound)return;v.__mpNativeBound=true;['loadedmetadata','canplay','play','playing','pause','ended','emptied'].forEach(function(e){v.addEventListener(e,report,{passive:true});});});report();}"
                        + "bind();new MutationObserver(bind).observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['src']});setInterval(report,700);"
                        + "window.MasterPlusNativePiP={pause:function(){var v=document.querySelector('video');if(v){try{v.pause();}catch(e){}}},resume:function(){var v=document.querySelector('video');if(v){try{var p=v.play();if(p&&p.catch)p.catch(function(){});}catch(e){}}}};"
                        + "function addSettingsRow(){if(document.getElementById('masterplus-native-config'))return;var all=[].slice.call(document.querySelectorAll('div,section,li'));var anchor=all.find(function(x){var t=(x.innerText||'').trim().toLowerCase();return t.indexOf('contáctanos')===0||t.indexOf('contactanos')===0;});if(!anchor)return;var row=document.createElement('div');row.id='masterplus-native-config';row.style.cssText='display:flex;align-items:center;gap:22px;padding:24px 32px;border-top:1px solid rgba(255,255,255,.09);border-bottom:1px solid rgba(255,255,255,.09);font-size:18px;color:#fff;cursor:pointer;background:#151419';row.innerHTML='<span style=\"font-size:25px;color:#ff5a16\">⚙</span><span style=\"flex:1\">Configuración</span><span style=\"font-size:30px;color:#999\">›</span>';row.onclick=function(){if(window.MasterPlusBridge)MasterPlusBridge.openBufferSettings();};anchor.parentNode.insertBefore(row,anchor.nextSibling);}setInterval(addSettingsRow,800);"
                        + "})();",
                null
        );
    }

    /**
     * Instala el diseño v11 para la pantalla de canales en vivo.
     * El reproductor y la barra del canal quedan fijos, mientras que las
     * categorías y los canales se desplazan de forma independiente.
     */
    private void installIndependentLiveListsLayout() {
        webView.evaluateJavascript(
                "(function(){"
                        + "if(window.__masterPlusV11LayoutInstalled){if(window.__mpV11Apply)window.__mpV11Apply();return;}"
                        + "window.__masterPlusV11LayoutInstalled=true;"
                        + "var style=document.getElementById('masterplus-v11-layout');"
                        + "if(!style){style=document.createElement('style');style.id='masterplus-v11-layout';"
                        + "style.textContent='"
                        + "html.mp-v11-live,html.mp-v11-live body{height:100%;overflow:hidden!important;}"
                        + "body.mp-v11-live{overscroll-behavior:none;}"
                        + "body.mp-v11-live #app{height:100%;min-height:0!important;overflow:hidden!important;}"
                        + "body.mp-v11-live .tv-app{height:100vh!important;min-height:0!important;padding-bottom:78px!important;display:flex!important;flex-direction:column!important;overflow:hidden!important;}"
                        + "body.mp-v11-live .top-video{flex:0 0 auto!important;position:relative!important;top:auto!important;}"
                        + "body.mp-v11-live .now-bar,body.mp-v11-live .search-panel{flex:0 0 auto!important;}"
                        + "body.mp-v11-live .content-split{flex:1 1 auto!important;height:auto!important;min-height:0!important;overflow:hidden!important;}"
                        + "body.mp-v11-live .category-pane,body.mp-v11-live .channel-pane{height:100%!important;min-height:0!important;overflow-x:hidden!important;overflow-y:auto!important;-webkit-overflow-scrolling:touch;overscroll-behavior:contain;touch-action:pan-y;}"
                        + "body.mp-v11-live .category-pane{scrollbar-gutter:stable;}"
                        + "body.mp-v11-live .channel-pane{scrollbar-gutter:stable;}"
                        + "body.mp-v11-live .bottom-nav{position:fixed!important;left:0!important;right:0!important;bottom:0!important;}"
                        + "';document.head.appendChild(style);}"
                        + "function apply(){var split=document.querySelector('.tv-app .content-split');var live=!!(split&&document.querySelector('.tv-app .top-video'));"
                        + "document.documentElement.classList.toggle('mp-v11-live',live);document.body.classList.toggle('mp-v11-live',live);}"
                        + "window.__mpV11Apply=apply;apply();"
                        + "new MutationObserver(function(){requestAnimationFrame(apply);}).observe(document.documentElement,{childList:true,subtree:true});"
                        + "window.addEventListener('resize',apply,{passive:true});"
                        + "})();",
                null
        );
    }

    private void prepareWebContentForPip(Runnable afterPreparation) {
        webView.evaluateJavascript(
                "(window.MasterPlusPiP&&window.MasterPlusPiP.prepare())?'true':'false'",
                value -> {
                    boolean prepared = "true".equals(value);
                    if (prepared || videoIsFullscreen || customView != null) {
                        mainHandler.postDelayed(afterPreparation, 80);
                    } else {
                        pipTransitionPending = false;
                        applyNormalInsets();
                    }
                }
        );
    }

    private void restoreWebContentAfterPip() {
        webView.evaluateJavascript(
                "window.MasterPlusPiP&&window.MasterPlusPiP.restore()",
                null
        );
    }

    private final class MasterPlusWebViewClient extends WebViewClient {

        @Override
        public boolean shouldOverrideUrlLoading(
                WebView view,
                WebResourceRequest request
        ) {
            return handleUri(request.getUrl());
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handleUri(Uri.parse(url));
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            captureMediaUrl(request.getUrl().toString());
            return super.shouldInterceptRequest(view, request);
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, String url) {
            captureMediaUrl(url);
            return super.shouldInterceptRequest(view, url);
        }

        private void captureMediaUrl(String url) {
            if (url == null) return;
            String clean = url.toLowerCase(Locale.ROOT);
            if (clean.contains(".m3u8") || clean.contains(".mp4") || clean.contains("manifest.mpd")) {
                latestMediaUrl = url;
                webVideoPlaying = true;
                mainHandler.post(() -> updatePictureInPictureParams(true));
            }
        }

        private boolean handleUri(Uri uri) {
            String scheme = uri.getScheme() == null
                    ? ""
                    : uri.getScheme().toLowerCase(Locale.ROOT);

            if ("http".equals(scheme) || "https".equals(scheme)) {
                String host = uri.getHost();

                if (host != null && (
                        host.equals(TRUSTED_HOST)
                        || host.endsWith("." + TRUSTED_HOST)
                )) {
                    return false;
                }

                // Permite que los streams HTTP/HTTPS se carguen dentro del WebView.
                // Los enlaces de navegación externos se abren fuera.
                String path = uri.getPath() == null ? "" : uri.getPath().toLowerCase(Locale.ROOT);
                if (
                        path.endsWith(".m3u8")
                        || path.endsWith(".mp4")
                        || path.endsWith(".ts")
                ) {
                    return false;
                }

                openExternal(uri);
                return true;
            }

            if (
                    "intent".equals(scheme)
                    || "whatsapp".equals(scheme)
                    || "mailto".equals(scheme)
                    || "tel".equals(scheme)
                    || "market".equals(scheme)
            ) {
                openExternal(uri);
                return true;
            }

            return false;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setProgress(10);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            progressBar.setProgress(100);
            progressBar.setVisibility(View.GONE);
            installVideoStateMonitor();
            installIndependentLiveListsLayout();
            installNativeSettingsEntry();
            mainHandler.postDelayed(() -> installNativeSettingsEntry(), 1200);
            mainHandler.postDelayed(() -> installNativeSettingsEntry(), 3000);
            captureAnalyticsContext();
            if (!analyticsStarted) {
                analyticsStarted = true;
                sendAnalyticsEvent("login");
            } else {
                sendAnalyticsEvent("page_view");
            }
        }

        @Override
        public void onReceivedError(
                WebView view,
                WebResourceRequest request,
                WebResourceError error
        ) {
            if (request.isForMainFrame()) {
                Toast.makeText(
                        MainActivity.this,
                        R.string.connection_error,
                        Toast.LENGTH_LONG
                ).show();
            }
        }
    }

    private final class MasterPlusChromeClient extends WebChromeClient {

        @Override
        public void onProgressChanged(WebView view, int newProgress) {
            progressBar.setProgress(newProgress);
            progressBar.setVisibility(
                    newProgress >= 100 ? View.GONE : View.VISIBLE
            );
        }

        @Override
        public boolean onShowFileChooser(
                WebView webView,
                ValueCallback<Uri[]> callback,
                FileChooserParams fileChooserParams
        ) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(null);
            }

            filePathCallback = callback;

            Intent intent;
            try {
                intent = fileChooserParams.createIntent();
            } catch (Exception error) {
                intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
            }

            try {
                startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                return true;
            } catch (ActivityNotFoundException error) {
                filePathCallback = null;
                Toast.makeText(
                        MainActivity.this,
                        R.string.no_app_found,
                        Toast.LENGTH_LONG
                ).show();
                return false;
            }
        }

        @Override
        public void onShowCustomView(
                View view,
                CustomViewCallback callback
        ) {
            if (customView != null) {
                callback.onCustomViewHidden();
                return;
            }

            customView = view;
            customViewCallback = callback;
            videoIsFullscreen = true;
            clearContentInsets();

            webView.setVisibility(View.GONE);
            rootContainer.addView(
                    customView,
                    new FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                    )
            );

            enterImmersiveMode();
        }

        @Override
        public void onHideCustomView() {
            if (customView == null) {
                return;
            }

            rootContainer.removeView(customView);
            customView = null;
            videoIsFullscreen = false;

            if (customViewCallback != null) {
                customViewCallback.onCustomViewHidden();
                customViewCallback = null;
            }

            webView.setVisibility(View.VISIBLE);
            exitImmersiveMode();
            applyNormalInsets();
        }

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            if (!isTrustedOrigin(request.getOrigin())) {
                request.deny();
                return;
            }

            pendingPermissionRequest = request;
            pendingAndroidPermissions = mapWebPermissions(request.getResources());

            if (pendingAndroidPermissions.length == 0) {
                request.grant(request.getResources());
                pendingPermissionRequest = null;
                return;
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(
                        pendingAndroidPermissions,
                        WEB_PERMISSION_REQUEST
                );
            } else {
                request.grant(request.getResources());
                pendingPermissionRequest = null;
            }
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(
                String origin,
                GeolocationPermissions.Callback callback
        ) {
            callback.invoke(origin, false, false);
        }
    }

    private boolean isTrustedOrigin(Uri origin) {
        String host = origin.getHost();
        return host != null && (
                host.equals(TRUSTED_HOST)
                || host.endsWith("." + TRUSTED_HOST)
        );
    }

    private String[] mapWebPermissions(String[] resources) {
        boolean camera = false;
        boolean microphone = false;

        for (String resource : resources) {
            if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(resource)) {
                camera = true;
            }

            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(resource)) {
                microphone = true;
            }
        }

        if (camera && microphone) {
            return new String[]{
                    Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO
            };
        }

        if (camera) {
            return new String[]{Manifest.permission.CAMERA};
        }

        if (microphone) {
            return new String[]{Manifest.permission.RECORD_AUDIO};
        }

        return new String[0];
    }

    private void openExternal(Uri uri) {
        try {
            Intent intent;

            if ("intent".equalsIgnoreCase(uri.getScheme())) {
                intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME);
            } else {
                intent = new Intent(Intent.ACTION_VIEW, uri);
            }

            startActivity(intent);
        } catch (Exception error) {
            Toast.makeText(
                    this,
                    R.string.no_app_found,
                    Toast.LENGTH_LONG
            ).show();
        }
    }


    private void configureSystemBars() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            getWindow().setStatusBarColor(0xFF111118);
            getWindow().setNavigationBarColor(0xFF111118);
        }

        rootContainer.setOnApplyWindowInsetsListener((view, insets) -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                android.graphics.Insets bars = insets.getInsets(
                        WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars()
                );
                systemInsetTop = bars.top;
                systemInsetBottom = bars.bottom;
            } else {
                systemInsetTop = insets.getSystemWindowInsetTop();
                systemInsetBottom = insets.getSystemWindowInsetBottom();
            }
            applyNormalInsets();
            return insets;
        });
        rootContainer.requestApplyInsets();
    }

    private void applyNormalInsets() {
        if (rootContainer == null || isInPictureInPictureMode() || videoIsFullscreen) {
            return;
        }
        rootContainer.setPadding(0, systemInsetTop, 0, systemInsetBottom);
    }

    private void clearContentInsets() {
        if (rootContainer != null) {
            rootContainer.setPadding(0, 0, 0, 0);
        }
    }

    private void updatePictureInPictureParams(boolean playing) {
        if (!canUsePictureInPicture()) {
            return;
        }
        try {
            PictureInPictureParams.Builder builder = new PictureInPictureParams.Builder()
                    .setAspectRatio(new Rational(16, 9));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                builder.setAutoEnterEnabled(playing);
                builder.setSeamlessResizeEnabled(true);
            }
            setPictureInPictureParams(builder.build());
        } catch (Exception ignored) {
        }
    }

    private boolean canUsePictureInPicture() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                && getPackageManager().hasSystemFeature(
                        PackageManager.FEATURE_PICTURE_IN_PICTURE
                );
    }

    private void enterPictureInPictureNow() {
        if (!canUsePictureInPicture() || isInPictureInPictureMode() || pipTransitionPending) {
            return;
        }
        if (latestMediaUrl == null || latestMediaUrl.isEmpty()) {
            Toast.makeText(this, "No se detectó la URL directa del video", Toast.LENGTH_SHORT).show();
            return;
        }

        pipTransitionPending = true;
        nativePipActive = true;
        clearContentInsets();
        webView.evaluateJavascript("window.MasterPlusNativePiP&&window.MasterPlusNativePiP.pause()", null);
        webView.setVisibility(View.GONE);
        progressBar.setVisibility(View.GONE);
        nativeVideoView.setVisibility(View.VISIBLE);

        try {
            Map<String, String> headers = new HashMap<>();
            headers.put("User-Agent", webView.getSettings().getUserAgentString());
            String cookie = CookieManager.getInstance().getCookie(latestMediaUrl);
            if (cookie != null && !cookie.isEmpty()) headers.put("Cookie", cookie);
            headers.put("Referer", webView.getUrl() == null ? BuildConfig.START_URL : webView.getUrl());

            nativeVideoView.setVideoURI(Uri.parse(latestMediaUrl), headers);
            nativeVideoView.setOnPreparedListener(mp -> {
                mp.setLooping(false);
                nativeVideoView.start();
            });
            nativeVideoView.setOnErrorListener((mp, what, extra) -> {
                mainHandler.post(this::restoreWebPlayer);
                return true;
            });
            nativeVideoView.start();

            PictureInPictureParams.Builder builder = new PictureInPictureParams.Builder()
                    .setAspectRatio(new Rational(16, 9));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                builder.setSeamlessResizeEnabled(true);
            }
            boolean entered = enterPictureInPictureMode(builder.build());
            if (!entered) restoreWebPlayer();
        } catch (Exception error) {
            restoreWebPlayer();
        } finally {
            pipTransitionPending = false;
        }
    }

    private void restoreWebPlayer() {
        if (nativeVideoView != null) {
            try { nativeVideoView.stopPlayback(); } catch (Exception ignored) {}
            nativeVideoView.setVisibility(View.GONE);
        }
        nativePipActive = false;
        webView.setVisibility(View.VISIBLE);
        webView.evaluateJavascript("window.MasterPlusNativePiP&&window.MasterPlusNativePiP.resume()", null);
        exitImmersiveMode();
        applyNormalInsets();
    }

    private void enterImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(
                        WindowInsets.Type.statusBars()
                                | WindowInsets.Type.navigationBars()
                );
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                );
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            );
        }
    }

    private void exitImmersiveMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.show(
                        WindowInsets.Type.statusBars()
                                | WindowInsets.Type.navigationBars()
                );
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_VISIBLE
            );
        }
    }


    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        enterPictureInPictureNow();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    public void onPictureInPictureModeChanged(
            boolean isInPictureInPictureMode,
            android.content.res.Configuration newConfig
    ) {
        super.onPictureInPictureModeChanged(
                isInPictureInPictureMode,
                newConfig
        );

        if (isInPictureInPictureMode) {
            clearContentInsets();
            enterImmersiveMode();
        } else {
            restoreWebPlayer();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null && !pm.isInteractive()) startBackgroundAudioIfPossible();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mainHandler.postDelayed(() -> installNativeSettingsEntry(), 700);
        mainHandler.postDelayed(() -> { captureAnalyticsContext(); sendAnalyticsEvent("resume"); }, 900);
        if (backgroundAudioActive) {
            stopBackgroundAudioAndRestore();
        }
        if (!isInPictureInPictureMode()) {
            if (nativePipActive) restoreWebPlayer();
            else applyNormalInsets();
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            ((MasterPlusChromeClient) webView.getWebChromeClient()).onHideCustomView();
            return;
        }

        if (webView.canGoBack()) {
            webView.goBack();
            return;
        }

        super.onBackPressed();
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data
    ) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != FILE_CHOOSER_REQUEST || filePathCallback == null) {
            return;
        }

        Uri[] results = WebChromeClient.FileChooserParams.parseResult(
                resultCode,
                data
        );

        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {
        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (
                requestCode != WEB_PERMISSION_REQUEST
                || pendingPermissionRequest == null
        ) {
            return;
        }

        boolean granted = true;

        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) {
                granted = false;
                break;
            }
        }

        if (granted) {
            pendingPermissionRequest.grant(
                    pendingPermissionRequest.getResources()
            );
        } else {
            pendingPermissionRequest.deny();
        }

        pendingPermissionRequest = null;
        pendingAndroidPermissions = null;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        webView.saveState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onDestroy() {
        mainHandler.removeCallbacks(analyticsHeartbeat);
        sendAnalyticsEvent("logout");
        if (analyticsReporter != null) analyticsReporter.shutdown();
        if (screenReceiverRegistered) {
            try { unregisterReceiver(screenStateReceiver); } catch (Exception ignored) {}
            screenReceiverRegistered = false;
        }
        if (audioReceiverRegistered) {
            try { unregisterReceiver(audioStateReceiver); } catch (Exception ignored) {}
            audioReceiverRegistered = false;
        }
        updateKeepScreenOn(false);
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
        }

        super.onDestroy();
    }
}
