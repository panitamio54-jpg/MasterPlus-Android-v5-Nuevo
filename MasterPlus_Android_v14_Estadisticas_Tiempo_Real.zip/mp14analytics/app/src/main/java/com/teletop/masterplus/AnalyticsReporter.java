package com.teletop.masterplus;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.webkit.CookieManager;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Envía actividad de la app al panel sin interferir con el reproductor.
 * El servidor identifica al usuario con la misma cookie de sesión del WebView.
 */
public final class AnalyticsReporter {
    private static final String ENDPOINT = "https://teletop.online/Masterplus/api/track.php";
    private final Context context;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public AnalyticsReporter(Context context) {
        this.context = context.getApplicationContext();
    }

    public void send(String eventType, String pageUrl, String contentName,
                     String categoryName, String contentType, boolean playing) {
        final Map<String, String> data = new LinkedHashMap<>();
        data.put("event_type", safe(eventType));
        data.put("page_url", safe(pageUrl));
        data.put("channel_name", safe(contentName));
        data.put("category_name", safe(categoryName));
        data.put("content_type", safe(contentType));
        data.put("is_playing", playing ? "1" : "0");
        data.put("device_model", Build.MANUFACTURER + " " + Build.MODEL);
        data.put("device_type", "Android");
        data.put("android_version", Build.VERSION.RELEASE);
        data.put("app_version", BuildConfig.VERSION_NAME);
        data.put("connection_type", getConnectionType());
        data.put("timestamp_ms", String.valueOf(System.currentTimeMillis()));

        executor.execute(() -> post(data, pageUrl));
    }

    private void post(Map<String, String> data, String pageUrl) {
        HttpURLConnection connection = null;
        try {
            StringBuilder body = new StringBuilder();
            for (Map.Entry<String, String> entry : data.entrySet()) {
                if (body.length() > 0) body.append('&');
                body.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                body.append('=');
                body.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
            }

            URL url = new URL(ENDPOINT);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(8000);
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("User-Agent", "MasterPlusAndroid/" + BuildConfig.VERSION_NAME);

            String cookieSource = pageUrl == null || pageUrl.isEmpty()
                    ? "https://teletop.online/Masterplus/" : pageUrl;
            String cookie = CookieManager.getInstance().getCookie(cookieSource);
            if (cookie != null && !cookie.isEmpty()) {
                connection.setRequestProperty("Cookie", cookie);
            }

            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream output = connection.getOutputStream()) {
                output.write(bytes);
            }
            connection.getResponseCode();
        } catch (Exception ignored) {
            // Las estadísticas nunca deben interrumpir la reproducción.
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private String getConnectionType() {
        try {
            ConnectivityManager cm = (ConnectivityManager)
                    context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return "Desconocida";
            Network network = cm.getActiveNetwork();
            if (network == null) return "Sin conexión";
            NetworkCapabilities caps = cm.getNetworkCapabilities(network);
            if (caps == null) return "Desconocida";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "Wi-Fi";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "Datos móviles";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) return "Ethernet";
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return "VPN";
            return "Otra";
        } catch (Exception ignored) {
            return "Desconocida";
        }
    }

    private static String safe(String value) {
        return value == null ? "" : value.trim();
    }

    public void shutdown() {
        executor.shutdownNow();
    }
}
