# MasterPlus Android v13

- Opción visible **Configuración** dentro de la pestaña ME.
- Búfer seleccionable: 40, 50, 60, 70 u 80 segundos.
- Activación/desactivación del audio con pantalla apagada.
- Reconexión automática configurable.
- El reproductor web se pausa solamente cuando ExoPlayer confirma que el audio de fondo está listo.
- Captura adicional de enlaces HLS mediante WebView, `fetch` y `XMLHttpRequest`.
- La integración EPG queda preparada para la siguiente etapa junto con el panel.
