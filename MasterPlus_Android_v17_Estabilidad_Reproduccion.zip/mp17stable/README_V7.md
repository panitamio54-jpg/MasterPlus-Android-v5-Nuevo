MasterPlus v7: PiP muestra solo el reproductor y oculta la navegación y las listas durante la ventana flotante. Conserva las correcciones de barras de v6.
