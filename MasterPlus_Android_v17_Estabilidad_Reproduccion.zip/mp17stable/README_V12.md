# MasterPlus Android v12

Cambios principales:
- Audio con pantalla apagada migrado a AndroidX Media3 ExoPlayer.
- Compatibilidad mejorada con HLS, redirecciones, cookies, User-Agent y Referer.
- Búfer configurable desde la pestaña ME: 40, 50, 60, 70 u 80 segundos.
- Selección adaptativa automática cuando el stream ofrece varias calidades.
- Se mantienen pantalla flotante y listas independientes de la v11.

Nota: el ajuste de búfer se aplica al audio en segundo plano. La calidad adaptativa depende de que el proveedor del canal publique varias variantes en el manifiesto HLS.
