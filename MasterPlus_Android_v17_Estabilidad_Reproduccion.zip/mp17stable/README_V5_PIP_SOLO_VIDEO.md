# MasterPlus v5 – PiP solo video

Esta versión prepara el contenido antes de entrar en Picture-in-Picture:

- PiP automático al pulsar Inicio mientras hay reproducción.
- Funciona desde reproducción normal, sin exigir pantalla completa.
- Oculta temporalmente la interfaz web y deja visible el elemento de video o reproductor.
- Desactiva los controles HTML del video durante PiP para evitar botones grandes sobre la imagen.
- Restaura la página completa al volver a la aplicación.
- Versión Android: 1.3.0 (versionCode 5).

## Compilar en GitHub

Abra **Actions / Comportamiento**, seleccione **Compilador APK MasterPlus v5 PiP Solo Video**, pulse **Run workflow** y descargue el artefacto al finalizar.
