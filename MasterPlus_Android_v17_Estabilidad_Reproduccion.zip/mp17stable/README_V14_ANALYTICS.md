# MasterPlus Android v14 - Estadísticas reales

Esta versión parte de la v13 estable y agrega únicamente telemetría hacia:

`https://teletop.online/Masterplus/api/track.php`

Envía: login, heartbeat cada 30 segundos, reproducción/pausa, modelo, Android, versión de app, red y contenido detectado.

No se modificaron la pantalla flotante, el audio en segundo plano ni la configuración de búfer.
