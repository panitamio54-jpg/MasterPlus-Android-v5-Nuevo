# MasterPlus Android

Aplicación Android nativa que abre:

`https://teletop.online/Masterplus/`

## Incluye

- WebView con JavaScript, almacenamiento local y cookies.
- Pantalla completa para video.
- Botón Atrás con historial de navegación.
- Selector de archivos para importaciones.
- Descargas mediante el administrador de Android.
- Apertura de WhatsApp, correo, teléfono y enlaces externos.
- Tráfico HTTP permitido para streams y películas que no tengan HTTPS.
- Contenido mixto HTTP dentro de la plataforma HTTPS.
- Icono y pantalla inicial MasterPlus.
- Proyecto preparado para Android 7.0 o superior.
- Flujo de GitHub Actions para compilar un APK automáticamente.

## Importante

La aplicación abre la versión web existente. Los cambios que hagas en el
servidor aparecerán en la aplicación sin volver a compilar el APK.

Para cambiar la dirección, edita `START_URL` dentro de `app/build.gradle`.
