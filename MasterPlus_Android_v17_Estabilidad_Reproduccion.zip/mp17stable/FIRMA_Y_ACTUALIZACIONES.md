# Firma y actualizaciones

Android solo permite actualizar una aplicación cuando la versión nueva está
firmada con la misma clave que la versión instalada.

## Recomendación

1. Crea una única clave `masterplus-release.jks`.
2. Guárdala en al menos dos lugares seguros.
3. No la envíes por chat ni la publiques.
4. Copia `signing.properties.example` como `signing.properties`.
5. Completa sus datos reales.
6. Compila con `assembleRelease`.

El APK firmado quedará en:

`app/build/outputs/apk/release/app-release.apk`

Si pierdes la clave, no podrás publicar actualizaciones sobre la misma
instalación; los clientes tendrían que desinstalar e instalar nuevamente.
