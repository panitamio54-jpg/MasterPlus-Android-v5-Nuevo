# MasterPlus v11

Mejoras incluidas:

- Conserva la ventana flotante (Picture-in-Picture) de la versión 10.
- Conserva el audio en segundo plano al apagar o bloquear la pantalla.
- En la pantalla de TV en vivo, el reproductor superior permanece fijo.
- La columna de categorías y la columna de canales ahora se desplazan de forma independiente.
- La barra inferior permanece fija y no se mueve con las listas.
- El ajuste se aplica únicamente a la vista de canales en vivo para no afectar Inicio, Partidos, Películas ni Mi cuenta.

Versión Android:

- `versionCode 11`
- `versionName 1.9.0`
