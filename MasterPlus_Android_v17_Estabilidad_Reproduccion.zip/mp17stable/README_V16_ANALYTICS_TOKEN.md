# MasterPlus Android v16 — Estadísticas con token real

Correcciones:
- lee `mp_token` y `mp_device` desde localStorage del WebView;
- envía `Authorization: Bearer ...`;
- envía `X-Device-ID` y `device_id` en la URL;
- conserva cookie como respaldo;
- no toca audio de fondo, PiP, búfer ni reproductor.

Versión:
- versionCode 18
- versionName 2.4.0
