# MasterPlus v6

- Corrige el contenido oculto detrás de las barras superior e inferior de Android.
- Refuerza PiP automático en Android 12 o superior y añade respaldo al salir de la app.
- Amplía la detección de reproductores HTML5, iframe, object y contenedores comunes.
