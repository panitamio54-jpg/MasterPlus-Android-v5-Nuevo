MasterPlus v8: PiP nativo con VideoView. La interfaz web se oculta en PiP y se reproduce la URL directa del video.
