# MasterPlus v10

Mejoras incluidas:

- Mantiene la pantalla encendida mientras el reproductor web está reproduciendo.
- Al apagar/bloquear la pantalla, transfiere el canal detectado a un servicio de audio en primer plano.
- Incluye notificación multimedia con reproducir/pausar y detener.
- Reanuda el reproductor visible al desbloquear y volver a la aplicación.
- Conserva PiP nativo, logo final y configuración de la versión anterior.

Nota: el audio con pantalla apagada depende de que la aplicación pueda detectar una URL directa compatible del canal, como HLS `.m3u8`, MP4 o DASH.
