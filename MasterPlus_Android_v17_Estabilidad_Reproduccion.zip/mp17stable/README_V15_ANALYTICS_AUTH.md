# MasterPlus Android v15 — Estadísticas autenticadas

Corrección principal:
- envía JSON compatible con `request_json()` de `api/track.php`;
- adjunta la cookie de sesión del WebView;
- conserva un `session_id` estable durante la ejecución;
- registra en Logcat respuestas HTTP 200, 401 y 500;
- no modifica pantalla flotante, audio de fondo, búfer ni reproductor.

Endpoint:
https://teletop.online/Masterplus/api/track.php

Versión:
- versionCode 17
- versionName 2.3.0
