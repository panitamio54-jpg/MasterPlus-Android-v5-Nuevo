# MasterPlus Android v17 — Estabilidad de reproducción

Cambios conservadores:
- mantiene reproducción visible únicamente en WebView;
- elimina modificaciones globales de fetch/XMLHttpRequest;
- reduce el sondeo JavaScript del video;
- reduce la frecuencia del heartbeat analytics;
- evita activar ExoPlayer por un simple onStop;
- el audio nativo solo se intenta al recibir ACTION_SCREEN_OFF;
- búfer de audio de fondo predeterminado moderado;
- mantiene PiP, estadísticas, configuración y audio de fondo.

Versión:
- versionCode 19
- versionName 2.5.0
