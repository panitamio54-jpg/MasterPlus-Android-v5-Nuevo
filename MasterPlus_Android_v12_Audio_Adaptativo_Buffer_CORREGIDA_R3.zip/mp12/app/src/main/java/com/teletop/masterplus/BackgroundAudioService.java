package com.teletop.masterplus;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;

import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;

import java.util.HashMap;
import java.util.Map;

public class BackgroundAudioService extends Service {
    public static final String ACTION_START = "com.teletop.masterplus.action.START_AUDIO";
    public static final String ACTION_TOGGLE = "com.teletop.masterplus.action.TOGGLE_AUDIO";
    public static final String ACTION_STOP = "com.teletop.masterplus.action.STOP_AUDIO";
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_USER_AGENT = "user_agent";
    public static final String EXTRA_COOKIE = "cookie";
    public static final String EXTRA_REFERER = "referer";
    public static final String PREFS = "masterplus_playback";
    public static final String PREF_BUFFER_SECONDS = "buffer_seconds";

    private static final String CHANNEL_ID = "masterplus_background_audio_v12";
    private static final int NOTIFICATION_ID = 1012;
    private ExoPlayer player;

    @Override public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;
        String action = intent.getAction();
        if (ACTION_STOP.equals(action)) { stopPlayback(); return START_NOT_STICKY; }
        if (ACTION_TOGGLE.equals(action)) {
            if (player != null) {
                if (player.isPlaying()) player.pause(); else player.play();
                updateNotification();
            }
            return START_STICKY;
        }
        if (ACTION_START.equals(action)) {
            String url = intent.getStringExtra(EXTRA_URL);
            if (url == null || url.trim().isEmpty()) return START_NOT_STICKY;
            startForeground(NOTIFICATION_ID, buildNotification(false));
            startPlayback(url, intent);
            return START_STICKY;
        }
        return START_NOT_STICKY;
    }

    private void startPlayback(String url, Intent intent) {
        releasePlayer();
        int seconds = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(PREF_BUFFER_SECONDS, 50);
        int bufferMs = Math.max(20, Math.min(120, seconds)) * 1000;

        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(bufferMs, bufferMs, 1500, 3000)
                .setPrioritizeTimeOverSizeThresholds(true)
                .build();

        Map<String,String> headers = new HashMap<>();
        String ua = intent.getStringExtra(EXTRA_USER_AGENT);
        String cookie = intent.getStringExtra(EXTRA_COOKIE);
        String referer = intent.getStringExtra(EXTRA_REFERER);
        if (cookie != null && !cookie.isEmpty()) headers.put("Cookie", cookie);
        if (referer != null && !referer.isEmpty()) headers.put("Referer", referer);

        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(20000)
                .setDefaultRequestProperties(headers);
        if (ua != null && !ua.isEmpty()) http.setUserAgent(ua);

        player = new ExoPlayer.Builder(this)
                .setLoadControl(loadControl)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(http))
                .setWakeMode(C.WAKE_MODE_NETWORK)
                .build();
        player.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build(), true);
        player.addListener(new Player.Listener() {
            @Override public void onIsPlayingChanged(boolean isPlaying) { updateNotification(); }
            @Override public void onPlaybackStateChanged(int state) { updateNotification(); }
            @Override public void onPlayerError(PlaybackException error) {
                // Reintento automático para cortes breves de internet o segmentos HLS fallidos.
                if (player != null) { player.prepare(); player.play(); }
            }
        });
        player.setMediaItem(MediaItem.fromUri(Uri.parse(url)));
        player.prepare();
        player.play();
    }

    private Notification buildNotification(boolean playing) {
        Intent open = new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(this,1,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent toggle = new Intent(this, BackgroundAudioService.class).setAction(ACTION_TOGGLE);
        PendingIntent togglePi = PendingIntent.getService(this,2,toggle,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, BackgroundAudioService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this,3,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT>=26 ? new Notification.Builder(this,CHANNEL_ID) : new Notification.Builder(this);
        return b.setSmallIcon(R.mipmap.ic_launcher).setContentTitle("MasterPlus")
                .setContentText(playing ? "Audio en segundo plano" : "Preparando transmisión…")
                .setContentIntent(openPi).setOngoing(playing).setCategory(Notification.CATEGORY_TRANSPORT)
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_media_play, playing?"Pausar":"Reproducir",togglePi).build())
                .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"Detener",stopPi).build())
                .build();
    }
    private void updateNotification() {
        NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, buildNotification(player!=null && player.isPlaying()));
    }
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT>=26) {
            NotificationChannel c=new NotificationChannel(CHANNEL_ID,"Audio en segundo plano",NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Reproducción de canales con la pantalla apagada");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }
    private void releasePlayer(){ if(player!=null){ player.release(); player=null; } }
    private void stopPlayback(){ releasePlayer(); stopForeground(true); stopSelf(); }
    @Override public void onDestroy(){ releasePlayer(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent){ return null; }
}
