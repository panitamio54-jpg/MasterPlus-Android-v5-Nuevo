# CapPlayer - Proyecto preparado para GitHub

Este proyecto está configurado para que **GitHub Actions compile la APK automáticamente**.

## API configurada

`https://teletop.online/capplayer_api/`

## Qué hace GitHub

Cada vez que subas cambios a la rama `main` o `master`, GitHub ejecutará:

1. Java 17.
2. Gradle 9.5.
3. Android SDK API 37.
4. Compilación `assembleDebug`.
5. Publicación del archivo `app-debug.apk` como artifact llamado **CapPlayer-APK**.

También puedes compilar manualmente desde:

**GitHub → Actions → Build CapPlayer APK → Run workflow**

## Cómo descargar la APK

Cuando el workflow termine en verde:

**GitHub → Actions → Build CapPlayer APK → última ejecución → Artifacts → CapPlayer-APK**

Dentro estará:

`app-debug.apk`

## Funciones incluidas en esta primera versión

- Activación por licencia.
- Registro de dispositivo.
- Sesión/token.
- Inicio.
- TV en vivo.
- Películas.
- Series y episodios.
- Favoritos.
- Reproductor Media3/ExoPlayer.
- Navegación básica con D-pad.
- Cierre correcto del reproductor para evitar audio en segundo plano.

## Importante

La base de datos de contenido todavía está vacía. La app puede compilar e instalar, pero TV/Películas/Series aparecerán vacías hasta cargar contenido en el servidor.

La contraseña MySQL **no está dentro de la APK**.
