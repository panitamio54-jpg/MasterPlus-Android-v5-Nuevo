CAPPLAYER ANDROID STARTER

API YA CONFIGURADA:
https://teletop.online/capplayer_api/

QUÉ INCLUYE ESTA VERSIÓN
- Activación por clave/licencia.
- ID único del dispositivo Android.
- Guarda sesión/token.
- Inicio.
- TV en vivo.
- Películas.
- Series y episodios.
- Favoritos (lectura).
- Reproductor Media3 / ExoPlayer.
- HLS + DASH + streams progresivos.
- Navegación básica con control remoto / D-pad.
- Libera correctamente el reproductor al salir para evitar audio en segundo plano.
- Diseño oscuro rojo/dorado inspirado en las capturas, pero con identidad propia.
- Compatible con celular, tablet, Android TV y TV Box.

REQUISITOS
- Android Studio compatible con Android Gradle Plugin 9.3.1.
- JDK 17.
- Android SDK 37.
- Internet para que Gradle descargue dependencias al abrir el proyecto.

CÓMO ABRIR
1. Descomprime este ZIP en una computadora.
2. Android Studio > Open.
3. Selecciona la carpeta CapPlayerAndroidStarter.
4. Espera a que Gradle sincronice.
5. Run para probar.

PRUEBA DE ACTIVACIÓN
1. Crea un usuario/licencia en:
   https://teletop.online/capplayer_panel/
2. Instala/ejecuta la app.
3. Escribe la clave de licencia.
4. La app registra el dispositivo automáticamente.

NOTA
La base de datos está vacía todavía. Por eso TV/Películas/Series mostrarán:
'Todavía no hay contenido cargado'.
El siguiente paso es preparar la importación/gestión de contenido.

SEGURIDAD
La APK NO contiene la contraseña de MySQL.
Solo se comunica con tu API HTTPS.
