package online.teletop.capplayer

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var activationPanel: View
    private lateinit var homePanel: View
    private lateinit var licenseInput: EditText
    private lateinit var status: TextView
    private lateinit var deviceCode: TextView
    private lateinit var pageTitle: TextView
    private lateinit var content: LinearLayout
    private lateinit var loading: ProgressBar
    private lateinit var prefs: android.content.SharedPreferences
    private var token: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences("capplayer", MODE_PRIVATE)
        token = prefs.getString("token", "") ?: ""

        activationPanel = findViewById(R.id.activationPanel)
        homePanel = findViewById(R.id.homePanel)
        licenseInput = findViewById(R.id.licenseInput)
        status = findViewById(R.id.activationStatus)
        deviceCode = findViewById(R.id.deviceCodeText)
        pageTitle = findViewById(R.id.pageTitle)
        content = findViewById(R.id.contentContainer)
        loading = findViewById(R.id.loading)

        val androidId = deviceId()
        deviceCode.text = "ID dispositivo: ${androidId.take(12).uppercase()}"

        findViewById<Button>(R.id.activateButton).setOnClickListener { activate(androidId) }
        findViewById<Button>(R.id.tabHome).setOnClickListener { showHome() }
        findViewById<Button>(R.id.tabLive).setOnClickListener { loadList("TV en vivo", "channels.php?limit=200", "channel") }
        findViewById<Button>(R.id.tabMovies).setOnClickListener { loadList("Películas", "movies.php?limit=150", "movie") }
        findViewById<Button>(R.id.tabSeries).setOnClickListener { loadList("Series", "series.php?limit=150", "series") }
        findViewById<Button>(R.id.refreshButton).setOnClickListener { showHome() }
        findViewById<Button>(R.id.logoutButton).setOnClickListener {
            prefs.edit().clear().apply()
            token = ""
            showActivation()
        }

        if (token.isBlank()) {
            showActivation()
        } else {
            validateSession()
        }
    }

    private fun deviceId(): String {
        return Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
            ?: "android-${System.currentTimeMillis()}"
    }

    private fun showActivation() {
        activationPanel.visibility = View.VISIBLE
        homePanel.visibility = View.GONE
    }

    private fun showApp() {
        activationPanel.visibility = View.GONE
        homePanel.visibility = View.VISIBLE
        showHome()
    }

    private fun activate(androidId: String) {
        val key = licenseInput.text.toString().trim().uppercase()
        if (key.isBlank()) {
            status.text = "Escribe la clave de activación."
            return
        }

        status.text = "Activando..."
        val body = JSONObject()
            .put("license_key", key)
            .put("device_id", androidId)
            .put("device_name", "${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")

        executor.execute {
            try {
                val result = ApiClient.postJson("activate.php", body)
                val json = JSONObject(result.body.ifBlank { "{}" })
                runOnUiThread {
                    if (result.code in 200..299 && json.optBoolean("success")) {
                        token = json.optString("token")
                        prefs.edit().putString("token", token).apply()
                        status.text = "Activado correctamente."
                        showApp()
                    } else {
                        status.text = json.optString("message", "No se pudo activar.")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Error de conexión: ${e.message ?: "desconocido"}" }
            }
        }
    }

    private fun validateSession() {
        executor.execute {
            try {
                val result = ApiClient.get("me.php", token)
                runOnUiThread {
                    if (result.code in 200..299) showApp() else {
                        prefs.edit().clear().apply()
                        token = ""
                        showActivation()
                    }
                }
            } catch (_: Exception) {
                runOnUiThread { showApp() }
            }
        }
    }

    private fun showHome() {
        pageTitle.text = "Inicio"
        content.removeAllViews()

        addHero("Modo activo", "Tu dispositivo está conectado a tu servidor.")
        addSectionTitle("Accesos rápidos")
        addAction("📺 TV en vivo") { loadList("TV en vivo", "channels.php?limit=200", "channel") }
        addAction("🎬 Películas") { loadList("Películas", "movies.php?limit=150", "movie") }
        addAction("📚 Series") { loadList("Series", "series.php?limit=150", "series") }
        addAction("❤️ Favoritos") { loadFavorites() }
    }

    private fun loadFavorites() {
        loadList("Favoritos", "favorites.php", "favorite")
    }

    private fun loadList(title: String, endpoint: String, kind: String) {
        pageTitle.text = title
        content.removeAllViews()
        loading.visibility = View.VISIBLE

        executor.execute {
            try {
                val result = ApiClient.get(endpoint, token)
                val json = JSONObject(result.body.ifBlank { "{}" })
                val arr = json.optJSONArray("data") ?: JSONArray()
                runOnUiThread {
                    loading.visibility = View.GONE
                    if (result.code !in 200..299) {
                        addInfo(json.optString("message", "No se pudo cargar el contenido."))
                        return@runOnUiThread
                    }
                    if (arr.length() == 0) {
                        addInfo("Todavía no hay contenido cargado en esta sección.")
                        return@runOnUiThread
                    }

                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        val itemTitle = item.optString(
                            if (kind == "movie" || kind == "series") "title" else "name",
                            "Contenido"
                        )
                        val subtitle = item.optString("category_name", "")
                        val streamUrl = item.optString("stream_url", "")
                        addContentCard(itemTitle, subtitle) {
                            when {
                                kind == "channel" && streamUrl.isNotBlank() ->
                                    openPlayer(itemTitle, streamUrl)
                                kind == "movie" && streamUrl.isNotBlank() ->
                                    openPlayer(itemTitle, streamUrl)
                                kind == "series" -> {
                                    val id = item.optInt("id")
                                    loadEpisodes(itemTitle, id)
                                }
                                else -> Toast.makeText(this, "Elemento guardado", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    loading.visibility = View.GONE
                    addInfo("Error: ${e.message ?: "sin conexión"}")
                }
            }
        }
    }

    private fun loadEpisodes(seriesTitle: String, seriesId: Int) {
        pageTitle.text = seriesTitle
        content.removeAllViews()
        loading.visibility = View.VISIBLE

        executor.execute {
            try {
                val result = ApiClient.get("episodes.php?series_id=$seriesId", token)
                val json = JSONObject(result.body.ifBlank { "{}" })
                val arr = json.optJSONArray("data") ?: JSONArray()
                runOnUiThread {
                    loading.visibility = View.GONE
                    if (arr.length() == 0) {
                        addInfo("Esta serie todavía no tiene episodios.")
                        return@runOnUiThread
                    }
                    for (i in 0 until arr.length()) {
                        val ep = arr.optJSONObject(i) ?: continue
                        val season = ep.optInt("season_number", 1)
                        val number = ep.optInt("episode_number", i + 1)
                        val title = ep.optString("title", "Episodio $number")
                        val url = ep.optString("stream_url")
                        addContentCard("T$season · E$number · $title", "") {
                            if (url.isNotBlank()) openPlayer("$seriesTitle - $title", url)
                        }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    loading.visibility = View.GONE
                    addInfo("Error cargando episodios.")
                }
            }
        }
    }

    private fun openPlayer(title: String, url: String) {
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra("title", title)
            putExtra("url", url)
        })
    }

    private fun addHero(title: String, subtitle: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22.dp(), 18.dp(), 22.dp(), 18.dp())
            background = getDrawable(R.drawable.bg_card)
        }
        box.addView(TextView(this).apply {
            text = title
            textSize = 22f
            setTextColor(getColor(R.color.gold))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        box.addView(TextView(this).apply {
            text = subtitle
            textSize = 15f
            setTextColor(getColor(R.color.white))
            setPadding(0, 8.dp(), 0, 0)
        })
        content.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 18.dp() })
    }

    private fun addSectionTitle(textValue: String) {
        content.addView(TextView(this).apply {
            text = textValue
            textSize = 21f
            setTextColor(getColor(R.color.white))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(4.dp(), 8.dp(), 4.dp(), 10.dp())
        })
    }

    private fun addAction(textValue: String, click: () -> Unit) {
        addContentCard(textValue, "", click)
    }

    private fun addContentCard(title: String, subtitle: String, click: () -> Unit) {
        val button = Button(this).apply {
            text = if (subtitle.isBlank()) title else "$title\n$subtitle"
            textSize = 16f
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
            setTextColor(getColor(R.color.white))
            background = getDrawable(R.drawable.bg_card)
            isFocusable = true
            isFocusableInTouchMode = false
            setPadding(18.dp(), 8.dp(), 18.dp(), 8.dp())
            setOnClickListener { click() }
        }
        content.addView(button, LinearLayout.LayoutParams(-1, 72.dp()).apply {
            bottomMargin = 10.dp()
        })
    }

    private fun addInfo(message: String) {
        content.addView(TextView(this).apply {
            text = message
            textSize = 17f
            setTextColor(getColor(R.color.muted))
            gravity = Gravity.CENTER
            setPadding(20.dp(), 40.dp(), 20.dp(), 40.dp())
        })
    }

    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
