package online.teletop.capplayer

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

object ApiClient {
    const val BASE_URL = "https://teletop.online/capplayer_api/"

    data class Result(val code: Int, val body: String)

    fun postJson(endpoint: String, json: JSONObject, token: String? = null): Result {
        val conn = URL(BASE_URL + endpoint).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 12000
        conn.readTimeout = 20000
        conn.doOutput = true
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
        conn.setRequestProperty("Accept", "application/json")
        if (!token.isNullOrBlank()) conn.setRequestProperty("Authorization", "Bearer $token")

        conn.outputStream.use { it.write(json.toString().toByteArray(Charsets.UTF_8)) }
        return read(conn)
    }

    fun get(endpoint: String, token: String): Result {
        val conn = URL(BASE_URL + endpoint).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 12000
        conn.readTimeout = 20000
        conn.setRequestProperty("Accept", "application/json")
        conn.setRequestProperty("Authorization", "Bearer $token")
        return read(conn)
    }

    private fun read(conn: HttpURLConnection): Result {
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val body = if (stream != null) {
            BufferedReader(InputStreamReader(stream)).use { it.readText() }
        } else ""
        conn.disconnect()
        return Result(code, body)
    }
}
